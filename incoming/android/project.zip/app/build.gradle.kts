plugins {
    id("com.android.application")
}

android {
    namespace = "com.onex.realtest"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.onex.realtest"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.3"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}