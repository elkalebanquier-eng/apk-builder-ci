package com.createurdapli.app;

import android.app.*;
import android.app.DownloadManager;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
  private static final int PICK_SOURCE=42, PICK_LOGO=43;
  private static final String RELAY="https://pzwhiqjnjmwosfyufwny.supabase.co/functions/v1/build-relay";
  private static final String KEY="sb_publishable_nwgB40SU7ixxBP8_bbyp-w_3cT2XlFt";
  private final ExecutorService io=Executors.newSingleThreadExecutor(); private final Handler handler=new Handler(Looper.getMainLooper());
  private Uri sourceUri, logoUri; private String sourceName="projet.zip", logoName=""; private String id, detected="android";
  private TextView sourceText, detectText, logoText, status, logs, stepText; private Button sourceButton, logoButton, buildButton, downloadButton; private ProgressBar progress; private RadioButton withLogo, withoutLogo;

  @Override public void onCreate(Bundle state){ super.onCreate(state); getWindow().setStatusBarColor(0xfff5f6fb); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); createUi(); }
  private TextView label(String s,int size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);return v;}
  private Button action(String s,int bg,int fg){Button v=new Button(this);v.setText(s);v.setTextSize(15);v.setTextColor(fg);v.setAllCaps(false);v.setBackgroundColor(bg);return v;}
  private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
  private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(22,20,22,20);c.setBackgroundColor(Color.WHITE);LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=14;c.setLayoutParams(p);return c;}

  private void createUi(){
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(22,28,22,24);root.setBackgroundColor(0xfff5f6fb);
    TextView title=label("Créateur Dapli",30,0xff141727);title.setTypeface(null,1);root.addView(title,lp(-1,-2));
    TextView sub=label("Du code source à votre APK debug, en quelques étapes.",16,0xff636879);sub.setPadding(0,6,0,20);root.addView(sub,lp(-1,-2));
    ScrollView scroll=new ScrollView(this);LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);

    LinearLayout source=card();TextView st=label("ÉTAPE 1",12,0xff5146e5);st.setTypeface(null,1);source.addView(st,lp(-1,-2));TextView sh=label("Choisir le code source",20,0xff141727);sh.setTypeface(null,1);source.addView(sh,lp(-1,-2));sourceText=label("Aucun fichier ZIP sélectionné",15,0xff686d7e);sourceText.setPadding(0,10,0,4);source.addView(sourceText,lp(-1,-2));
    sourceButton=action("Sélectionner un fichier ZIP",0xffecebff,0xff4d43c4);sourceButton.setOnClickListener(v->pickSource());source.addView(sourceButton,lp(-1,52));detectText=label("Le type du projet sera détecté automatiquement.",14,0xff777c8d);detectText.setPadding(0,10,0,0);source.addView(detectText,lp(-1,-2));content.addView(source);

    LinearLayout logo=card();TextView lt=label("ÉTAPE 2",12,0xff5146e5);lt.setTypeface(null,1);logo.addView(lt,lp(-1,-2));TextView lh=label("Choisir le logo de l’application",20,0xff141727);lh.setTypeface(null,1);logo.addView(lh,lp(-1,-2));TextView hint=label("Vous pouvez utiliser le logo présent dans votre projet ou en sélectionner un nouveau.",14,0xff686d7e);hint.setPadding(0,8,0,8);logo.addView(hint,lp(-1,-2));
    RadioGroup group=new RadioGroup(this);group.setOrientation(RadioGroup.VERTICAL);withoutLogo=new RadioButton(this);withoutLogo.setText("Sans logo personnalisé");withoutLogo.setTextSize(15);withoutLogo.setChecked(true);withLogo=new RadioButton(this);withLogo.setText("Ajouter un logo personnalisé");withLogo.setTextSize(15);group.addView(withoutLogo);group.addView(withLogo);logo.addView(group,lp(-1,-2));
    logoButton=action("Choisir une image PNG ou JPG",0xfff0f0f6,0xff454858);logoButton.setVisibility(View.GONE);logoButton.setOnClickListener(v->pickLogo());logo.addView(logoButton,lp(-1,50));logoText=label("",14,0xff167a45);logoText.setPadding(0,6,0,0);logo.addView(logoText,lp(-1,-2));withLogo.setOnCheckedChangeListener((b,checked)->{logoButton.setVisibility(checked?View.VISIBLE:View.GONE);if(!checked){logoUri=null;logoText.setText("");}});content.addView(logo);

    LinearLayout build=card();TextView bt=label("ÉTAPE 3",12,0xff5146e5);bt.setTypeface(null,1);build.addView(bt,lp(-1,-2));TextView bh=label("Compiler et suivre la progression",20,0xff141727);bh.setTypeface(null,1);build.addView(bh,lp(-1,-2));stepText=label("En attente de votre projet",15,0xff686d7e);stepText.setPadding(0,8,0,8);build.addView(stepText,lp(-1,-2));progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);progress.setProgress(0);progress.setVisibility(View.GONE);build.addView(progress,lp(-1,10));status=label("Prêt à compiler",15,0xff343747);status.setPadding(0,10,0,0);build.addView(status,lp(-1,-2));logs=label("",13,0xff777c8d);logs.setPadding(0,8,0,0);build.addView(logs,lp(-1,-2));buildButton=action("Lancer la compilation APK",0xff5146e5,Color.WHITE);buildButton.setOnClickListener(v->startBuild());build.addView(buildButton,lp(-1,54));downloadButton=action("Télécharger l’APK debug",0xffe3f7eb,0xff157a45);downloadButton.setVisibility(View.GONE);downloadButton.setOnClickListener(v->downloadApk());build.addView(downloadButton,lp(-1,54));content.addView(build);
    TextView footer=label("Le résultat sera une APK debug installable sur votre appareil.",13,0xff777c8d);footer.setGravity(Gravity.CENTER);footer.setPadding(12,4,12,18);content.addView(footer,lp(-1,-2));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
  }

  private void pickSource(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");startActivityForResult(i,PICK_SOURCE);}
  private void pickLogo(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");startActivityForResult(i,PICK_LOGO);}
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null)return;if(request==PICK_SOURCE){sourceUri=data.getData();sourceName=displayName(sourceUri);sourceText.setText(sourceName);detectText.setText("Analyse du projet en cours…");io.execute(()->detectZip(sourceUri));}else if(request==PICK_LOGO){logoUri=data.getData();logoName=displayName(logoUri);logoText.setText("Logo sélectionné : "+logoName);}}
  private String displayName(Uri u){Cursor c=getContentResolver().query(u,null,null,null,null);try{if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}finally{if(c!=null)c.close();}return "fichier";}
  private void detectZip(Uri u){boolean android=false,html=false;try{InputStream in=getContentResolver().openInputStream(u);ZipInputStream z=new ZipInputStream(in);ZipEntry e;while((e=z.getNextEntry())!=null){String n=e.getName().toLowerCase();if(n.equals("settings.gradle")||n.equals("settings.gradle.kts")||n.endsWith("/androidmanifest.xml")||n.equals("gradlew"))android=true;if(n.equals("index.html")||n.endsWith("/index.html"))html=true;}z.close();detected=android?"android":html?"html":"android"; final boolean nativeProject=android;run(()->{detectText.setText(nativeProject?"Type détecté : Android natif":"Type détecté : projet web (index.html)");stepText.setText(nativeProject?"Projet Android prêt à compiler":"Projet web détecté : conversion Android prête");});}catch(Exception e){run(()->detectText.setText("Type non reconnu : le compilateur analysera le projet."));}}

  private void startBuild(){if(sourceUri==null){toast("Sélectionnez d’abord un fichier ZIP.");return;}setBusy(true);status.setText("Envoi du projet…");logs.setText("• Préparation du fichier source\n• Vérification du type : "+(detected.equals("html")?"index.html":"Android natif"));io.execute(()->{try{String boundary="----Dapli"+System.currentTimeMillis();HttpURLConnection c=(HttpURLConnection)new URL(RELAY+"/builds").openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("apikey",KEY);c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);OutputStream o=c.getOutputStream();field(o,boundary,"target",detected);field(o,boundary,"filename",sourceName);field(o,boundary,"logo_mode",withLogo.isChecked()?"custom":"none");if(withLogo.isChecked())field(o,boundary,"logo_filename",logoName);o.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"project\"; filename=\""+sourceName+"\"\r\nContent-Type: application/zip\r\n\r\n").getBytes());InputStream in=getContentResolver().openInputStream(sourceUri);byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)o.write(buf,0,n);in.close();o.write(("\r\n--"+boundary+"--\r\n").getBytes());o.close();JSONObject x=new JSONObject(read(c));id=x.getString("id");poll();}catch(Exception e){run(()->{status.setText("Échec de l’envoi");logs.setText("• "+e.getMessage());setBusy(false);});}});}
  private void field(OutputStream o,String b,String n,String v)throws Exception{o.write(("--"+b+"\r\nContent-Disposition: form-data; name=\""+n+"\"\r\n\r\n"+v+"\r\n").getBytes());}
  private void poll(){io.execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(RELAY+"/builds/"+id).openConnection();c.setRequestProperty("apikey",KEY);JSONObject x=new JSONObject(read(c));String s=x.optString("status");JSONArray a=x.optJSONArray("logs");StringBuilder out=new StringBuilder();if(a!=null)for(int i=0;i<a.length();i++)out.append("• ").append(a.getString(i)).append("\n");run(()->{status.setText(textStatus(s));logs.setText(out.toString());progress.setProgress("completed".equals(s)?100:"building".equals(s)?55:15);if("completed".equals(s)){downloadButton.setVisibility(View.VISIBLE);setBusy(false);}else if("failed".equals(s)){setBusy(false);}else handler.postDelayed(this::poll,2500);});}catch(Exception e){handler.postDelayed(this::poll,3500);}});}
  private String textStatus(String s){if("queued".equals(s))return "En attente du compilateur…";if("building".equals(s))return "Compilation en cours — vous voyez la progression en direct";if("completed".equals(s))return "Compilation terminée : APK debug prête";if("failed".equals(s))return "La compilation a échoué";return "Préparation…";}
  private void downloadApk(){DownloadManager.Request r=new DownloadManager.Request(Uri.parse(RELAY+"/builds/"+id+"/apk"));r.setTitle("Créateur Dapli — APK debug");r.setDescription("Téléchargement de votre application");r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);r.setMimeType("application/vnd.android.package-archive");((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(r);toast("Téléchargement démarré.");}
  private String read(HttpURLConnection c)throws Exception{InputStream i=c.getResponseCode()>=400?c.getErrorStream():c.getInputStream();BufferedReader r=new BufferedReader(new InputStreamReader(i));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l);r.close();return s.toString();}
  private void run(Runnable r){runOnUiThread(r);}private void setBusy(boolean b){sourceButton.setEnabled(!b);logoButton.setEnabled(!b);buildButton.setEnabled(!b);progress.setVisibility(b?View.VISIBLE:View.GONE);}private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}@Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
}
