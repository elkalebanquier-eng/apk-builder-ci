package com.createurdapli.app;

import android.app.*;
import android.app.DownloadManager;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
  private static final int PICK=42;
  private static final String RELAY="https://pzwhiqjnjmwosfyufwny.supabase.co/functions/v1/build-relay";
  private static final String KEY="sb_publishable_nwgB40SU7ixxBP8_bbyp-w_3cT2XlFt";
  private final ExecutorService io=Executors.newSingleThreadExecutor(); private final Handler h=new Handler(Looper.getMainLooper());
  private Uri uri; private String name="projet.zip", id; private TextView file,status,logs; private Button choose,build,download; private ProgressBar bar;
  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(0xfff6f7fb); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); ui();}
  private void ui(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(28,42,28,28); r.setBackgroundColor(0xfff6f7fb);
    TextView title=t("Créateur Dapli",30,0xff151827); title.setTypeface(null,1); r.addView(title,lp(-1,-2)); TextView sub=t("Transformez votre projet en application Android.",16,0xff5e6375); sub.setPadding(0,8,0,24); r.addView(sub,lp(-1,-2));
    LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(22,22,22,22); c.setBackgroundColor(Color.WHITE); r.addView(c,lp(-1,-2));
    TextView a=t("1  •  Choisir le code source",18,0xff151827); a.setTypeface(null,1); c.addView(a,lp(-1,-2)); file=t("Aucun fichier sélectionné\nFormat accepté : .zip",15,0xff777c8d); file.setPadding(0,14,0,14); c.addView(file,lp(-1,-2));
    choose=btn("Choisir un fichier ZIP",0xffe9e7ff,0xff4f46c5); choose.setOnClickListener(v->pick()); c.addView(choose,lp(-1,54));
    TextView b=t("2  •  Lancer la compilation",18,0xff151827); b.setTypeface(null,1); b.setPadding(0,28,0,0); c.addView(b,lp(-1,-2)); build=btn("Compiler en APK debug",0xff5146e5,Color.WHITE); build.setOnClickListener(v->start()); c.addView(build,lp(-1,54));
    bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); bar.setMax(100); bar.setVisibility(View.GONE); LinearLayout.LayoutParams bp=lp(-1,10); bp.topMargin=18; c.addView(bar,bp);
    status=t("Prêt à compiler",15,0xff5e6375); status.setPadding(0,14,0,0); c.addView(status,lp(-1,-2)); logs=t("",13,0xff777c8d); logs.setPadding(0,10,0,0); c.addView(logs,lp(-1,-2)); download=btn("Télécharger l’APK debug",0xffe8f8ef,0xff167a45); download.setVisibility(View.GONE); download.setOnClickListener(v->download()); c.addView(download,lp(-1,54));
    TextView n=t("Vos fichiers sont traités automatiquement pendant la compilation.",13,0xff777c8d); n.setGravity(Gravity.CENTER); n.setPadding(12,24,12,0); r.addView(n,lp(-1,-2)); setContentView(r); }
  private TextView t(String s,int z,int col){TextView x=new TextView(this);x.setText(s);x.setTextSize(z);x.setTextColor(col);return x;} private Button btn(String s,int bg,int fg){Button x=new Button(this);x.setText(s);x.setTextSize(15);x.setTextColor(fg);x.setAllCaps(false);x.setBackgroundColor(bg);return x;} private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
  private void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");startActivityForResult(i,PICK);} @Override protected void onActivityResult(int r,int q,Intent d){super.onActivityResult(r,q,d);if(r==PICK&&q==RESULT_OK&&d!=null){uri=d.getData();name=nameOf(uri);file.setText(name+"\nFichier prêt à être envoyé");}}
  private String nameOf(Uri u){Cursor c=getContentResolver().query(u,null,null,null,null);try{if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}finally{if(c!=null)c.close();}return "projet.zip";}
  private void start(){if(uri==null){toast("Choisissez d’abord un fichier ZIP.");return;} setBusy(true);status.setText("Envoi du projet…");io.execute(()->{try{String bd="----Dapli"+System.currentTimeMillis();HttpURLConnection c=(HttpURLConnection)new URL(RELAY+"/builds").openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("apikey",KEY);c.setRequestProperty("Content-Type","multipart/form-data; boundary="+bd);OutputStream o=c.getOutputStream();part(o,bd,"target",null,"android");part(o,bd,"filename",null,name);o.write(("--"+bd+"\r\nContent-Disposition: form-data; name=\"project\"; filename=\""+name+"\"\r\nContent-Type: application/zip\r\n\r\n").getBytes());InputStream in=getContentResolver().openInputStream(uri);byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)o.write(buf,0,n);in.close();o.write(("\r\n--"+bd+"--\r\n").getBytes());o.close();id=new JSONObject(read(c)).getString("id");poll();}catch(Exception e){run(()->{status.setText("Échec de l’envoi");logs.setText(e.getMessage());setBusy(false);});}});}
  private void part(OutputStream o,String b,String n,String f,String v)throws Exception{o.write(("--"+b+"\r\nContent-Disposition: form-data; name=\""+n+"\"\r\n\r\n"+v+"\r\n").getBytes());}
  private void poll(){io.execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(RELAY+"/builds/"+id).openConnection();c.setRequestProperty("apikey",KEY);JSONObject x=new JSONObject(read(c));String s=x.optString("status");JSONArray a=x.optJSONArray("logs");StringBuilder z=new StringBuilder();if(a!=null)for(int i=0;i<a.length();i++)z.append("• ").append(a.getString(i)).append("\n");run(()->{status.setText(label(s));logs.setText(z.toString());bar.setProgress("completed".equals(s)?100:"building".equals(s)?55:15);if("completed".equals(s)){download.setVisibility(View.VISIBLE);setBusy(false);}else if("failed".equals(s)){setBusy(false);}else h.postDelayed(this::poll,2500);});}catch(Exception e){h.postDelayed(this::poll,3500);}});}
  private String label(String s){if("queued".equals(s))return "Projet en attente…";if("building".equals(s))return "Compilation en cours…";if("completed".equals(s))return "APK debug prête";if("failed".equals(s))return "La compilation a échoué";return "Préparation…";}
  private void download(){DownloadManager.Request r=new DownloadManager.Request(Uri.parse(RELAY+"/builds/"+id+"/apk"));r.setTitle("Créateur Dapli — APK debug");r.setDescription("Téléchargement de votre application");r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);r.setMimeType("application/vnd.android.package-archive");((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(r);toast("Téléchargement démarré.");}
  private String read(HttpURLConnection c)throws Exception{InputStream i=c.getResponseCode()>=400?c.getErrorStream():c.getInputStream();BufferedReader r=new BufferedReader(new InputStreamReader(i));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l);r.close();return s.toString();} private void run(Runnable r){runOnUiThread(r);} private void setBusy(boolean b){choose.setEnabled(!b);build.setEnabled(!b);bar.setVisibility(b?View.VISIBLE:View.GONE);}private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}@Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
}
