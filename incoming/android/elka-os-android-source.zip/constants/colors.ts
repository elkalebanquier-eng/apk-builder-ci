/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#f4f7f5',
    tint: '#a7f34a',

    // Core surfaces
    background: '#0b100f',
    foreground: '#f4f7f5',

    // Cards / elevated surfaces
    card: '#131b18',
    cardForeground: '#f4f7f5',

    // Primary action color (buttons, links, active states)
    primary: '#a7f34a',
    primaryForeground: '#0b100f',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#1c2823',
    secondaryForeground: '#dce8df',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#18231f',
    mutedForeground: '#8ea195',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#263a2c',
    accentForeground: '#dfffc1',

    // Destructive actions (delete, error states)
    destructive: '#ef6262',
    destructiveForeground: '#1d0909',

    // Borders and input outlines
    border: '#26362e',
    input: '#2f4439',
  },

  dark: {
    text: '#f4f7f5',
    tint: '#a7f34a',
    background: '#0b100f',
    foreground: '#f4f7f5',
    card: '#131b18',
    cardForeground: '#f4f7f5',
    primary: '#a7f34a',
    primaryForeground: '#0b100f',
    secondary: '#1c2823',
    secondaryForeground: '#dce8df',
    muted: '#18231f',
    mutedForeground: '#8ea195',
    accent: '#263a2c',
    accentForeground: '#dfffc1',
    destructive: '#ef6262',
    destructiveForeground: '#1d0909',
    border: '#26362e',
    input: '#2f4439',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 8,
};

export default colors;
