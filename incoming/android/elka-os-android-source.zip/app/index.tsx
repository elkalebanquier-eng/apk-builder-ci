import { Feather } from '@expo/vector-icons';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useMemo, useRef, useState } from 'react';
import { useColors } from '@/hooks/useColors';
import {
  type AssistantMode,
  type ChatMessage,
  type ModelId,
  ElkaProvider,
  useElka,
} from '@/providers/ElkaProvider';

function AppContent() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    models,
    selectedModelId,
    mode,
    setMode,
    loadedModelId,
    modelBusyId,
    modelProgress,
    modelStatus,
    messages,
    generating,
    downloadModel,
    deleteModel,
    loadModel,
    sendMessage,
    clearConversation,
  } = useElka();
  const [modelSheetVisible, setModelSheetVisible] = useState(false);
  const [draft, setDraft] = useState('');
  const inputRef = useRef<TextInput>(null);
  const visibleMessages = useMemo(() => [...messages].reverse(), [messages]);
  const selectedModel = models.find((model) => model.id === selectedModelId);

  const onSend = async () => {
    const text = draft.trim();
    if (!text || generating) return;
    setDraft('');
    try {
      await sendMessage(text);
    } catch (error) {
      Alert.alert('IA locale indisponible', error instanceof Error ? error.message : String(error));
    }
  };

  const onModelAction = async (id: ModelId, downloaded: boolean) => {
    try {
      if (!downloaded) {
        await downloadModel(id);
      } else {
        await loadModel(id);
        setModelSheetVisible(false);
      }
    } catch (error) {
      Alert.alert('Modèle local', error instanceof Error ? error.message : String(error));
    }
  };

  const renderMessage = ({ item }: { item: ChatMessage }) => (
    <View
      style={[
        styles.messageRow,
        item.role === 'user' ? styles.userRow : styles.assistantRow,
      ]}
    >
      <View
        style={[
          styles.avatar,
          {
            backgroundColor: item.role === 'user' ? colors.secondary : colors.primary,
          },
        ]}
      >
        <Feather
          name={item.role === 'user' ? 'user' : 'cpu'}
          size={14}
          color={item.role === 'user' ? colors.secondaryForeground : colors.primaryForeground}
        />
      </View>
      <View
        style={[
          styles.bubble,
          {
            backgroundColor: item.role === 'user' ? colors.secondary : colors.card,
            borderColor: colors.border,
          },
        ]}
      >
        <Text style={[styles.messageText, { color: colors.foreground }]}>
          {item.content || '…'}
        </Text>
      </View>
    </View>
  );

  return (
    <KeyboardAvoidingView
      style={[styles.root, { backgroundColor: colors.background }]}
      behavior="padding"
      keyboardVerticalOffset={0}
    >
      <View
        style={[
          styles.header,
          { paddingTop: insets.top + 12, borderBottomColor: colors.border },
        ]}
      >
        <View style={styles.brandRow}>
          <View style={[styles.logo, { backgroundColor: colors.primary }]}>
            <Text style={[styles.logoText, { color: colors.primaryForeground }]}>E</Text>
          </View>
          <View>
            <Text style={[styles.brand, { color: colors.foreground }]}>ELKA OS</Text>
            <View style={styles.subtitleRow}>
              <View style={[styles.liveDot, { backgroundColor: colors.primary }]} />
              <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
                LOCAL · HORS LIGNE
              </Text>
            </View>
          </View>
        </View>
        <View style={styles.headerActions}>
          <Pressable
            accessibilityLabel="Gérer les modèles"
            testID="open-models"
            onPress={() => setModelSheetVisible(true)}
            style={({ pressed }) => [
              styles.iconButton,
              { backgroundColor: colors.secondary, opacity: pressed ? 0.7 : 1 },
            ]}
          >
            <Feather name="cpu" size={18} color={colors.foreground} />
          </Pressable>
          <Pressable
            accessibilityLabel="Nouvelle conversation"
            testID="clear-chat"
            onPress={() => void clearConversation()}
            style={({ pressed }) => [
              styles.iconButton,
              { backgroundColor: colors.secondary, opacity: pressed ? 0.7 : 1 },
            ]}
          >
            <Feather name="edit-3" size={18} color={colors.foreground} />
          </Pressable>
        </View>
      </View>

      <View style={styles.statusWrap}>
        <View style={[styles.modelPill, { backgroundColor: colors.accent }]}>
          <Feather name="zap" size={14} color={colors.primary} />
          <Text style={[styles.modelPillText, { color: colors.accentForeground }]}>
            {loadedModelId ? selectedModel?.name : 'Aucun modèle chargé'}
          </Text>
        </View>
        <Text style={[styles.status, { color: colors.mutedForeground }]} numberOfLines={1}>
          {modelStatus}
        </Text>
        <View style={[styles.modeSwitch, { backgroundColor: colors.secondary }]}>
          {(['assistant', 'code'] as AssistantMode[]).map((nextMode) => (
            <Pressable
              key={nextMode}
              testID={`mode-${nextMode}`}
              onPress={() => void setMode(nextMode)}
              style={[
                styles.modeOption,
                mode === nextMode && { backgroundColor: colors.primary },
              ]}
            >
              <Feather
                name={nextMode === 'code' ? 'code' : 'message-circle'}
                size={13}
                color={mode === nextMode ? colors.primaryForeground : colors.mutedForeground}
              />
              <Text
                style={[
                  styles.modeOptionText,
                  { color: mode === nextMode ? colors.primaryForeground : colors.mutedForeground },
                ]}
              >
                {nextMode === 'code' ? 'MODE CODE' : 'ASSISTANT'}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <FlatList
        data={visibleMessages}
        inverted={visibleMessages.length > 0}
        renderItem={renderMessage}
        keyExtractor={(item) => item.id}
        style={styles.messages}
        contentContainerStyle={[
          styles.messageContent,
          visibleMessages.length === 0 && styles.emptyContent,
        ]}
        keyboardDismissMode="interactive"
        keyboardShouldPersistTaps="handled"
        scrollEnabled={visibleMessages.length > 0}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.accent }]}>
              <Feather name="cpu" size={28} color={colors.primary} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              Ton assistant local
            </Text>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              Télécharge un modèle, charge-le une fois, puis discute sans connexion Internet.
            </Text>
            <Pressable
              testID="empty-manage-models"
              onPress={() => setModelSheetVisible(true)}
              style={({ pressed }) => [
                styles.primaryButton,
                { backgroundColor: colors.primary, opacity: pressed ? 0.78 : 1 },
              ]}
            >
              <Feather name="download-cloud" size={17} color={colors.primaryForeground} />
              <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>
                Gérer les modèles
              </Text>
            </Pressable>
          </View>
        }
        ListHeaderComponent={
          generating ? (
            <View style={styles.typingRow}>
              <ActivityIndicator size="small" color={colors.primary} />
              <Text style={[styles.typingText, { color: colors.mutedForeground }]}>
                Génération locale…
              </Text>
            </View>
          ) : null
        }
      />

      <View
        style={[
          styles.composerWrap,
          { paddingBottom: Math.max(insets.bottom, 12), borderTopColor: colors.border },
        ]}
      >
        <View style={[styles.composer, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <TextInput
            ref={inputRef}
            testID="message-input"
            value={draft}
            onChangeText={setDraft}
            placeholder={loadedModelId ? 'Écris à ELKA…' : 'Charge un modèle pour commencer'}
            placeholderTextColor={colors.mutedForeground}
            editable={Boolean(loadedModelId) && !generating}
            multiline
            maxLength={4000}
            style={[styles.input, { color: colors.foreground }]}
            onSubmitEditing={() => void onSend()}
            blurOnSubmit={false}
          />
          <Pressable
            testID="send-message"
            accessibilityLabel="Envoyer le message"
            disabled={!draft.trim() || !loadedModelId || generating}
            onPress={() => void onSend()}
            style={({ pressed }) => [
              styles.sendButton,
              {
                backgroundColor: colors.primary,
                opacity: !draft.trim() || !loadedModelId || generating ? 0.35 : pressed ? 0.72 : 1,
              },
            ]}
          >
            <Feather name="arrow-up" size={19} color={colors.primaryForeground} />
          </Pressable>
        </View>
        <Text style={[styles.privacy, { color: colors.mutedForeground }]}>
          Traitement sur le téléphone · aucune donnée envoyée
        </Text>
      </View>

      <Modal
        visible={modelSheetVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setModelSheetVisible(false)}
      >
        <View style={styles.modalBackdrop}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setModelSheetVisible(false)} />
          <View
            style={[
              styles.modelSheet,
              { backgroundColor: colors.background, paddingBottom: Math.max(insets.bottom, 20) },
            ]}
          >
            <View style={styles.sheetHandle} />
            <View style={styles.sheetHeader}>
              <View>
                <Text style={[styles.sheetTitle, { color: colors.foreground }]}>Modèles locaux</Text>
                <Text style={[styles.sheetDescription, { color: colors.mutedForeground }]}>
                  Télécharge une fois, utilise ensuite sans Internet.
                </Text>
              </View>
              <Pressable onPress={() => setModelSheetVisible(false)} style={styles.closeButton}>
                <Feather name="x" size={21} color={colors.mutedForeground} />
              </Pressable>
            </View>
            {models.map((model) => {
              const isBusy = modelBusyId === model.id;
              const isLoaded = loadedModelId === model.id;
              return (
                <View
                  key={model.id}
                  style={[
                    styles.modelCard,
                    {
                      backgroundColor: colors.card,
                      borderColor: isLoaded ? colors.primary : colors.border,
                    },
                  ]}
                >
                  <View style={styles.modelCardTop}>
                    <View style={[styles.modelIcon, { backgroundColor: colors.accent }]}>
                        <Feather
                          name={model.id === 'promax' ? 'star' : model.id === 'code' ? 'code' : 'cpu'}
                          size={18}
                          color={colors.primary}
                        />
                    </View>
                    <View style={styles.modelCopy}>
                      <View style={styles.modelNameRow}>
                        <Text style={[styles.modelName, { color: colors.foreground }]}>
                          {model.name}
                        </Text>
                        {isLoaded && (
                          <Text style={[styles.loadedLabel, { color: colors.primary }]}>ACTIF</Text>
                        )}
                      </View>
                      <Text style={[styles.modelMeta, { color: colors.mutedForeground }]}>
                        {model.sizeLabel} · {model.description}
                      </Text>
                    </View>
                  </View>
                  {isBusy && (
                    <View style={styles.progressBlock}>
                      <View style={[styles.progressTrack, { backgroundColor: colors.secondary }]}>
                        <View
                          style={[
                            styles.progressFill,
                            { backgroundColor: colors.primary, width: `${Math.max(modelProgress, 0.03) * 100}%` },
                          ]}
                        />
                      </View>
                      <Text style={[styles.progressText, { color: colors.mutedForeground }]}>
                        {modelProgress > 0 ? `${Math.round(modelProgress * 100)} %` : 'Préparation…'}
                      </Text>
                    </View>
                  )}
                  <View style={styles.modelActions}>
                    <Text style={[styles.storageLabel, { color: colors.mutedForeground }]}>
                      {model.downloaded ? 'Disponible sur le téléphone' : 'Pas encore téléchargé'}
                    </Text>
                    <Pressable
                      testID={`model-action-${model.id}`}
                      disabled={Boolean(modelBusyId)}
                      onPress={() => void onModelAction(model.id, model.downloaded)}
                      style={({ pressed }) => [
                        styles.smallButton,
                        {
                          backgroundColor: model.downloaded ? colors.primary : colors.secondary,
                          opacity: modelBusyId || pressed ? 0.65 : 1,
                        },
                      ]}
                    >
                      {isBusy ? (
                        <ActivityIndicator size="small" color={model.downloaded ? colors.primaryForeground : colors.foreground} />
                      ) : (
                        <Feather
                          name={model.downloaded ? (isLoaded ? 'check' : 'play') : 'download'}
                          size={15}
                          color={model.downloaded ? colors.primaryForeground : colors.foreground}
                        />
                      )}
                      <Text
                        style={[
                          styles.smallButtonText,
                          { color: model.downloaded ? colors.primaryForeground : colors.foreground },
                        ]}
                      >
                        {model.downloaded ? (isLoaded ? 'Chargé' : 'Charger') : 'Télécharger'}
                      </Text>
                    </Pressable>
                  </View>
                  {model.downloaded && !isLoaded && (
                    <Pressable
                      onPress={() =>
                        Alert.alert(
                          'Supprimer le modèle ?',
                          `${model.name} sera retiré du stockage du téléphone.`,
                          [
                            { text: 'Annuler', style: 'cancel' },
                            { text: 'Supprimer', style: 'destructive', onPress: () => void deleteModel(model.id) },
                          ],
                        )
                      }
                      style={styles.deleteLink}
                    >
                      <Text style={[styles.deleteText, { color: colors.destructive }]}>
                        Libérer cet espace
                      </Text>
                    </Pressable>
                  )}
                </View>
              );
            })}
            <Text style={[styles.sheetFootnote, { color: colors.mutedForeground }]}>
              Le premier téléchargement nécessite Internet. Une fois le modèle chargé, active le mode avion : ELKA continue de fonctionner localement.
            </Text>
          </View>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}

export default function HomeScreen() {
  return (
    <ElkaProvider>
      <AppContent />
    </ElkaProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
    paddingBottom: 13,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logo: {
    width: 34,
    height: 34,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoText: { fontFamily: 'Inter_700Bold', fontSize: 19 },
  brand: { fontFamily: 'Inter_700Bold', fontSize: 17, letterSpacing: 0.5 },
  subtitleRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 },
  liveDot: { width: 6, height: 6, borderRadius: 3 },
  subtitle: { fontFamily: 'Inter_600SemiBold', fontSize: 9, letterSpacing: 1.1 },
  headerActions: { flexDirection: 'row', gap: 8 },
  iconButton: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  statusWrap: { paddingHorizontal: 18, paddingVertical: 12, gap: 8 },
  modelPill: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 9 },
  modelPillText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  status: { fontFamily: 'Inter_400Regular', fontSize: 11 },
  modeSwitch: { alignSelf: 'flex-start', flexDirection: 'row', padding: 3, borderRadius: 10, gap: 2 },
  modeOption: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 9, paddingVertical: 6, borderRadius: 8 },
  modeOptionText: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 0.3 },
  messages: { flex: 1 },
  messageContent: { paddingHorizontal: 18, paddingTop: 10, paddingBottom: 18 },
  emptyContent: { flexGrow: 1, justifyContent: 'center' },
  emptyState: { alignItems: 'center', paddingHorizontal: 25 },
  emptyIcon: { width: 66, height: 66, borderRadius: 22, alignItems: 'center', justifyContent: 'center', marginBottom: 17 },
  emptyTitle: { fontFamily: 'Inter_700Bold', fontSize: 21, marginBottom: 9 },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20, textAlign: 'center', marginBottom: 22 },
  primaryButton: { flexDirection: 'row', alignItems: 'center', gap: 8, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12 },
  primaryButtonText: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  messageRow: { flexDirection: 'row', gap: 9, marginBottom: 16, alignItems: 'flex-start' },
  userRow: { flexDirection: 'row-reverse' },
  assistantRow: { flexDirection: 'row' },
  avatar: { width: 27, height: 27, borderRadius: 9, alignItems: 'center', justifyContent: 'center', marginTop: 2 },
  bubble: { maxWidth: '83%', borderWidth: 1, borderRadius: 15, paddingHorizontal: 13, paddingVertical: 10 },
  messageText: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 21 },
  typingRow: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 12 },
  typingText: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  composerWrap: { paddingTop: 10, paddingHorizontal: 14, borderTopWidth: StyleSheet.hairlineWidth },
  composer: { minHeight: 52, maxHeight: 130, borderRadius: 17, borderWidth: 1, flexDirection: 'row', alignItems: 'flex-end', padding: 6, gap: 6 },
  input: { flex: 1, minHeight: 38, maxHeight: 110, paddingHorizontal: 8, paddingTop: 9, paddingBottom: 8, fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 20 },
  sendButton: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  privacy: { textAlign: 'center', fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 7 },
  modalBackdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.56)' },
  modelSheet: { borderTopLeftRadius: 25, borderTopRightRadius: 25, paddingHorizontal: 18, paddingTop: 10, maxHeight: '90%' },
  sheetHandle: { width: 38, height: 4, borderRadius: 2, backgroundColor: '#65726a', alignSelf: 'center', marginBottom: 17 },
  sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 },
  sheetTitle: { fontFamily: 'Inter_700Bold', fontSize: 21 },
  sheetDescription: { fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 4 },
  closeButton: { padding: 4 },
  modelCard: { borderWidth: 1, borderRadius: 15, padding: 13, marginBottom: 10 },
  modelCardTop: { flexDirection: 'row', gap: 10 },
  modelIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  modelCopy: { flex: 1 },
  modelNameRow: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  modelName: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  loadedLabel: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 0.7 },
  modelMeta: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, marginTop: 3 },
  progressBlock: { marginTop: 12 },
  progressTrack: { height: 5, borderRadius: 3, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 3 },
  progressText: { fontFamily: 'Inter_500Medium', fontSize: 10, textAlign: 'right', marginTop: 4 },
  modelActions: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 12, gap: 8 },
  storageLabel: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 10 },
  smallButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, borderRadius: 9, paddingHorizontal: 10, paddingVertical: 8 },
  smallButtonText: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  deleteLink: { alignSelf: 'flex-end', marginTop: 9 },
  deleteText: { fontFamily: 'Inter_500Medium', fontSize: 10 },
  sheetFootnote: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15, marginTop: 5, marginBottom: 5 },
});
