import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system/legacy';
import { initLlama, type LlamaContext, type TokenData } from '@/providers/llama';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

const MESSAGE_STORAGE_KEY = '@elka/messages';
const SELECTED_MODEL_KEY = '@elka/selected-model';
const MODE_STORAGE_KEY = '@elka/mode';
const MODEL_DIRECTORY = FileSystem.documentDirectory
  ? `${FileSystem.documentDirectory}models/`
  : null;
const STOP_WORDS = [
  '</s>',
  '<|end|>',
  '<|eot_id|>',
  '<|end_of_text|>',
  '<|im_end|>',
];

export type ModelId = 'mini' | 'pro' | 'code' | 'promax';
export type AssistantMode = 'assistant' | 'code';

export type ModelDefinition = {
  id: ModelId;
  name: string;
  sizeLabel: string;
  fileName: string;
  url: string;
  description: string;
  category: 'general' | 'code';
};

export type ModelState = ModelDefinition & {
  downloaded: boolean;
  bytes?: number;
  progress: number;
};

export type ChatMessage = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: number;
};

const MODEL_CATALOG: ModelDefinition[] = [
  {
    id: 'mini',
    name: 'ELKA Mini',
    sizeLabel: '~397 Mo',
    fileName: 'qwen2.5-0.5b-instruct-q4_k_m.gguf',
    url: 'https://huggingface.co/bartowski/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/Qwen2.5-0.5B-Instruct-Q4_K_M.gguf?download=true',
    description: 'Rapide et léger pour les téléphones modestes.',
    category: 'general',
  },
  {
    id: 'pro',
    name: 'ELKA Pro',
    sizeLabel: '~986 Mo',
    fileName: 'qwen2.5-1.5b-instruct-q4_k_m.gguf',
    url: 'https://huggingface.co/bartowski/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf?download=true',
    description: 'Le meilleur équilibre entre vitesse et qualité.',
    category: 'general',
  },
  {
    id: 'code',
    name: 'ELKA Code',
    sizeLabel: '~986 Mo',
    fileName: 'qwen2.5-coder-1.5b-instruct-q4_k_m.gguf',
    url: 'https://huggingface.co/bartowski/Qwen2.5-Coder-1.5B-Instruct-GGUF/resolve/main/Qwen2.5-Coder-1.5B-Instruct-Q4_K_M.gguf?download=true',
    description: 'Spécialisé en code, projets web et applications.',
    category: 'code',
  },
  {
    id: 'promax',
    name: 'ELKA Pro Max',
    sizeLabel: '~1,93 Go',
    fileName: 'qwen2.5-3b-instruct-q4_k_m.gguf',
    url: 'https://huggingface.co/bartowski/Qwen2.5-3B-Instruct-GGUF/resolve/main/Qwen2.5-3B-Instruct-Q4_K_M.gguf?download=true',
    description: 'Réponses plus riches, demande plus de mémoire.',
    category: 'general',
  },
];

type ElkaContextValue = {
  models: ModelState[];
  selectedModelId: ModelId;
  mode: AssistantMode;
  loadedModelId: ModelId | null;
  modelBusyId: ModelId | null;
  modelProgress: number;
  modelStatus: string;
  messages: ChatMessage[];
  generating: boolean;
  refreshModels: () => Promise<void>;
  downloadModel: (id: ModelId) => Promise<void>;
  deleteModel: (id: ModelId) => Promise<void>;
  loadModel: (id: ModelId) => Promise<void>;
  sendMessage: (text: string) => Promise<void>;
  clearConversation: () => Promise<void>;
  setMode: (mode: AssistantMode) => Promise<void>;
};

const ElkaContext = createContext<ElkaContextValue | null>(null);

function createId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

function getModelPath(model: ModelDefinition): string {
  if (!MODEL_DIRECTORY) {
    throw new Error('Le stockage local n’est pas disponible sur cette plateforme.');
  }
  return `${MODEL_DIRECTORY}${model.fileName}`;
}

function getErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function initialModels(): ModelState[] {
  return MODEL_CATALOG.map((model) => ({
    ...model,
    downloaded: false,
    progress: 0,
  }));
}

export function ElkaProvider({ children }: { children: React.ReactNode }) {
  const [models, setModels] = useState<ModelState[]>(initialModels);
  const [selectedModelId, setSelectedModelId] = useState<ModelId>('mini');
  const [mode, setModeState] = useState<AssistantMode>('assistant');
  const [loadedModelId, setLoadedModelId] = useState<ModelId | null>(null);
  const [modelBusyId, setModelBusyId] = useState<ModelId | null>(null);
  const [modelProgress, setModelProgress] = useState(0);
  const [modelStatus, setModelStatus] = useState('Mode hors ligne prêt');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [generating, setGenerating] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const contextRef = useRef<LlamaContext | null>(null);
  const downloadRef = useRef<FileSystem.DownloadResumable | null>(null);

  const refreshModels = useCallback(async () => {
    if (!MODEL_DIRECTORY) return;
    await FileSystem.makeDirectoryAsync(MODEL_DIRECTORY, { intermediates: true });
    const nextModels = await Promise.all(
      MODEL_CATALOG.map(async (model) => {
        const info = await FileSystem.getInfoAsync(getModelPath(model));
        return {
          ...model,
          downloaded: info.exists,
          bytes: info.exists && 'size' in info ? info.size : undefined,
          progress: info.exists ? 1 : 0,
        };
      }),
    );
    setModels(nextModels);
  }, []);

  useEffect(() => {
    let mounted = true;
    Promise.all([
      AsyncStorage.getItem(MESSAGE_STORAGE_KEY),
      AsyncStorage.getItem(SELECTED_MODEL_KEY),
      AsyncStorage.getItem(MODE_STORAGE_KEY),
      refreshModels(),
    ]).then(([savedMessages, savedModel, savedMode]) => {
      if (!mounted) return;
      if (savedMessages) {
        try {
          setMessages(JSON.parse(savedMessages) as ChatMessage[]);
        } catch {
          setMessages([]);
        }
      }
      if (savedModel === 'mini' || savedModel === 'pro' || savedModel === 'code' || savedModel === 'promax') {
        setSelectedModelId(savedModel);
      }
      if (savedMode === 'assistant' || savedMode === 'code') {
        setModeState(savedMode);
      }
      setHydrated(true);
    });
    return () => {
      mounted = false;
      void downloadRef.current?.cancelAsync();
      void contextRef.current?.release();
    };
  }, [refreshModels]);

  useEffect(() => {
    if (hydrated) {
      void AsyncStorage.setItem(MESSAGE_STORAGE_KEY, JSON.stringify(messages));
    }
  }, [hydrated, messages]);

  const downloadModel = useCallback(
    async (id: ModelId) => {
      const model = MODEL_CATALOG.find((item) => item.id === id);
      if (!model || !MODEL_DIRECTORY) {
        throw new Error('Ce modèle ne peut pas être téléchargé sur cette plateforme.');
      }
      if (modelBusyId) return;

      setModelBusyId(id);
      setModelProgress(0);
      setModelStatus(`Téléchargement de ${model.name}…`);
      try {
        await FileSystem.makeDirectoryAsync(MODEL_DIRECTORY, { intermediates: true });
        const target = getModelPath(model);
        const existing = await FileSystem.getInfoAsync(target);
        if (existing.exists) {
          await FileSystem.deleteAsync(target, { idempotent: true });
        }
        const resumable = FileSystem.createDownloadResumable(
          model.url,
          target,
          {},
          ({ totalBytesWritten, totalBytesExpectedToWrite }) => {
            if (totalBytesExpectedToWrite > 0) {
              setModelProgress(totalBytesWritten / totalBytesExpectedToWrite);
            }
          },
        );
        downloadRef.current = resumable;
        const result = await resumable.downloadAsync();
        if (!result?.uri) throw new Error('Le téléchargement n’a pas produit de fichier.');
        setModelStatus(`${model.name} est disponible hors ligne.`);
        await refreshModels();
      } catch (error) {
        setModelStatus(`Téléchargement interrompu : ${getErrorMessage(error)}`);
        throw error;
      } finally {
        downloadRef.current = null;
        setModelBusyId(null);
      }
    },
    [modelBusyId, refreshModels],
  );

  const deleteModel = useCallback(
    async (id: ModelId) => {
      const model = MODEL_CATALOG.find((item) => item.id === id);
      if (!model) return;
      if (loadedModelId === id) {
        await contextRef.current?.release();
        contextRef.current = null;
        setLoadedModelId(null);
      }
      await FileSystem.deleteAsync(getModelPath(model), { idempotent: true });
      setModelStatus(`${model.name} supprimé du téléphone.`);
      await refreshModels();
    },
    [loadedModelId, refreshModels],
  );

  const loadModel = useCallback(
    async (id: ModelId) => {
      const model = MODEL_CATALOG.find((item) => item.id === id);
      const state = models.find((item) => item.id === id);
      if (!model || !state?.downloaded) {
        throw new Error('Télécharge d’abord ce modèle pour l’utiliser hors ligne.');
      }
      if (loadedModelId === id && contextRef.current) {
        setSelectedModelId(id);
        await AsyncStorage.setItem(SELECTED_MODEL_KEY, id);
        return;
      }

      setModelBusyId(id);
      setModelProgress(0);
      setModelStatus(`Chargement de ${model.name} dans la mémoire…`);
      try {
        await contextRef.current?.release();
        contextRef.current = await initLlama(
          {
            model: getModelPath(model),
            use_mlock: false,
            // Mobile-safe profile: fewer active CPU threads and smaller batches
            // reduce sustained heat without making short answers feel sluggish.
            n_ctx: 3072,
            n_batch: 256,
            n_ubatch: 128,
            n_threads: 4,
            n_gpu_layers: 0,
          },
          (progress) => setModelProgress(progress),
        );
        setLoadedModelId(id);
        setSelectedModelId(id);
        if (id === 'code') {
          setModeState('code');
          await AsyncStorage.setItem(MODE_STORAGE_KEY, 'code');
        }
        await AsyncStorage.setItem(SELECTED_MODEL_KEY, id);
        setModelStatus(`${model.name} chargé. Tu peux couper Internet.`);
      } catch (error) {
        setModelStatus(`Impossible de charger le modèle : ${getErrorMessage(error)}`);
        throw error;
      } finally {
        setModelBusyId(null);
      }
    },
    [loadedModelId, models],
  );

  const sendMessage = useCallback(
    async (text: string) => {
      const prompt = text.trim();
      if (!prompt || generating) return;
      const context = contextRef.current;
      if (!context) {
        throw new Error('Télécharge puis charge un modèle local avant de discuter.');
      }

      const userMessage: ChatMessage = {
        id: createId('user'),
        role: 'user',
        content: prompt,
        createdAt: Date.now(),
      };
      const assistantId = createId('assistant');
      const assistantMessage: ChatMessage = {
        id: assistantId,
        role: 'assistant',
        content: '',
        createdAt: Date.now(),
      };
      const conversation = [...messages, userMessage];
      setMessages([...conversation, assistantMessage]);
      setGenerating(true);
      setModelStatus('ELKA réfléchit sur l’appareil…');

      let streamedText = '';
      const updateAssistant = (data: TokenData) => {
        const token = data.token || data.content || '';
        if (!token) return;
        streamedText += token;
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantId
              ? { ...message, content: streamedText }
              : message,
          ),
        );
      };

      try {
        const result = await context.completion(
          {
            messages: [
              {
                role: 'system',
                content:
                  mode === 'code'
                    ? 'Tu es ELKA Code, un assistant local spécialisé dans la création d’applications. Réponds en français. Donne une solution fonctionnelle et directement exploitable. Pour une demande de code, indique les chemins de fichiers, fournis le code complet des fichiers nécessaires, évite le pseudo-code et limite les explications inutiles. Si le projet est trop grand, construis d’abord une petite version complète puis propose les extensions. Tu fonctionnes sans Internet.'
                    : 'Tu es ELKA OS, un assistant local créé par ELKA à Ouagadougou. Réponds en français, clairement et utilement. Tu fonctionnes sans Internet.',
              },
              ...conversation.map((message) => ({
                role: message.role,
                content: message.content,
              })),
            ],
            n_predict: mode === 'code' ? 640 : 384,
            temperature: mode === 'code' ? 0.2 : 0.7,
            top_p: 0.9,
            stop: STOP_WORDS,
          },
          updateAssistant,
        );
        const finalText = result.text?.trim() || streamedText.trim();
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantId
              ? {
                  ...message,
                  content: finalText || 'Je n’ai pas généré de réponse.',
                }
              : message,
          ),
        );
        setModelStatus('Réponse générée hors ligne.');
      } catch (error) {
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantId
              ? { ...message, content: `Erreur locale : ${getErrorMessage(error)}` }
              : message,
          ),
        );
        setModelStatus('Une erreur locale est survenue.');
        throw error;
      } finally {
        setGenerating(false);
      }
    },
    [generating, messages, mode],
  );

  const clearConversation = useCallback(async () => {
    setMessages([]);
    await contextRef.current?.clearCache(true);
    await AsyncStorage.removeItem(MESSAGE_STORAGE_KEY);
    setModelStatus('Nouvelle conversation locale.');
  }, []);

  const setMode = useCallback(async (nextMode: AssistantMode) => {
    setModeState(nextMode);
    await AsyncStorage.setItem(MODE_STORAGE_KEY, nextMode);
  }, []);

  const value = useMemo(
    () => ({
      models,
      selectedModelId,
      mode,
      loadedModelId,
      modelBusyId,
      modelProgress,
      modelStatus,
      messages,
      generating,
      refreshModels,
      downloadModel,
      deleteModel,
      loadModel,
      sendMessage,
      clearConversation,
      setMode,
    }),
    [
      models,
      selectedModelId,
      mode,
      loadedModelId,
      modelBusyId,
      modelProgress,
      modelStatus,
      messages,
      generating,
      refreshModels,
      downloadModel,
      deleteModel,
      loadModel,
      sendMessage,
      clearConversation,
      setMode,
    ],
  );

  return <ElkaContext.Provider value={value}>{children}</ElkaContext.Provider>;
}

export function useElka() {
  const value = useContext(ElkaContext);
  if (!value) throw new Error('useElka doit être utilisé dans ElkaProvider.');
  return value;
}
