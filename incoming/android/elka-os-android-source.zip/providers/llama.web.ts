export type TokenData = {
  token: string;
  content?: string;
};

export type LlamaContext = {
  completion: never;
  release: () => Promise<void>;
  clearCache: (clearData?: boolean) => Promise<void>;
};

export async function initLlama(): Promise<LlamaContext> {
  throw new Error(
    'Le moteur local est disponible dans la version Android compilée, pas dans l’aperçu web.',
  );
}
