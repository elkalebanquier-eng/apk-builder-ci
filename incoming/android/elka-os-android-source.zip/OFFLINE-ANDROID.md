# ELKA OS Android hors ligne

Cette application Android exécute les réponses avec `llama.cpp` via `llama.rn`.
Les modèles sont des fichiers GGUF téléchargés une seule fois dans le stockage
privé de l’application. Une fois le modèle chargé, le chat ne fait aucun appel
réseau.

## Modèles inclus dans le gestionnaire

| Modèle | Taille indicative | Usage |
| --- | ---: | --- |
| ELKA Mini | 397 Mo | Téléphones avec peu de mémoire |
| ELKA Pro | 986 Mo | Équilibre qualité/vitesse |
| ELKA Code | 986 Mo | Code, interfaces web et applications |
| ELKA Pro Max | 1,93 Go | Réponses plus riches, téléphone puissant |

Les fichiers sont téléchargés depuis Hugging Face uniquement quand l’utilisateur
appuie sur **Télécharger**. Ils ne sont pas inclus dans l’APK afin d’éviter une
APK de plusieurs gigaoctets.

## Compilation Android

Pré-requis :

- Node.js 20 ou 24
- pnpm
- Android Studio et Android SDK
- Un appareil Android ARM64 ou un émulateur compatible

Depuis la racine du projet :

```bash
pnpm install
pnpm --filter @workspace/elka-os-android exec expo prebuild --platform android
pnpm --filter @workspace/elka-os-android exec expo run:android
```

Pour générer un APK release :

```bash
cd artifacts/elka-os-android/android
./gradlew assembleRelease
```

Le fichier se trouve ensuite dans :

```text
artifacts/elka-os-android/android/app/build/outputs/apk/release/app-release.apk
```

Le plugin `llama.rn` télécharge ses bibliothèques natives pendant
`pnpm install`. Le projet autorise explicitement son script de build dans
`pnpm-workspace.yaml`.

## Utilisation sans Internet

1. Installe l’APK.
2. Ouvre **Modèles locaux**.
3. Télécharge **ELKA Mini** ou un modèle plus grand.
4. Appuie sur **Charger**.
5. Vérifie que le badge affiche **LOCAL · HORS LIGNE** et que le modèle est
   actif.
6. Active le mode avion et envoie un message.

Le modèle reste dans le stockage privé de l’application après fermeture et
redémarrage. Supprimer un modèle depuis l’écran de gestion libère son espace.

## Notes mémoire

Les modèles GGUF consomment de la mémoire vive pendant l’inférence. Pour éviter
les plantages :

- commence par **ELKA Mini** sur un téléphone d’entrée de gamme ;
- utilise **ELKA Pro** avec au moins 3 Go de RAM disponibles ;
- utilise **ELKA Code** pour programmer ; il privilégie la précision et les réponses courtes ;
- réserve **ELKA Pro Max** aux téléphones avec suffisamment de RAM libre ;
- garde une seule conversation raisonnablement courte pour les appareils limités.

Le profil mobile utilise quatre threads CPU, des lots de 256 tokens et des
réponses limitées. Cela réduit la chauffe par rapport à une configuration
maximisant les threads et les lots. Pour coder, active **MODE CODE** et charge
**ELKA Code**. Pour un gros projet, demande à l’assistant de produire les
fichiers un par un plutôt qu’une réponse géante.

L’aperçu navigateur sert à vérifier l’interface. Le moteur llama.cpp est
disponible dans l’APK Android compilée, car les modules natifs ne fonctionnent
pas dans le navigateur.
